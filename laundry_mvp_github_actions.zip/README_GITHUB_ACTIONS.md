# GitHub Actions로 APK 자동 빌드
1) GitHub에 새 리포지토리 생성 → 이 폴더 전체 업로드
2) Actions 탭 → `Android Debug APK` 실행 (또는 main 브랜치로 push 시 자동 실행)
3) 실행이 끝나면 `Artifacts`에 `app-debug.apk`가 생깁니다. 클릭해서 다운로드하세요.
4) APK를 휴대폰에 전송(이메일/드라이브/카톡) → 설치
